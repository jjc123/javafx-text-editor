/*
 * This is a text editor.
 */
package javafxtexteditor;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.Pane;
import javafx.scene.control.MenuBar;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import java.util.*;
import java.io.*;
import javafx.collections.*;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ButtonBar.ButtonData;

/**
 *
 * @author Jordan Clay
 */
public class JavaFXTextEditor extends Application {

    boolean isFile = false;
    String filename = "";
    TextArea textBox = new TextArea();
    Stage primaryStage;
    Alert saveError = new Alert(AlertType.ERROR);
    Alert openError = new Alert(AlertType.ERROR);
    Boolean canceled = false;

    @Override
    public void start(Stage primaryStage) {
        Menu fileMenu = new Menu("File");
        MenuItem newFileItem = new MenuItem("New");
        MenuItem openFileItem = new MenuItem("Open");
        MenuItem saveFileItem = new MenuItem("Save");
        MenuItem saveAsFileItem = new MenuItem("Save As");
        newFileItem.setOnAction(new NewHandler());
        openFileItem.setOnAction(new OpenHandler());
        saveFileItem.setOnAction(new SaveHandler());
        saveAsFileItem.setOnAction(new SaveAsHandler());
        fileMenu.getItems().addAll(newFileItem, openFileItem, saveFileItem, saveAsFileItem);

        Menu documentMenu = new Menu("Document");
        MenuItem replaceDocumentItem = new MenuItem("Replace");
        replaceDocumentItem.setOnAction(new ReplaceHandler());
        documentMenu.getItems().addAll(replaceDocumentItem);

        MenuBar topBar = new MenuBar();

        topBar.getMenus().addAll(fileMenu, documentMenu);

        textBox.relocate(0, 24);
        textBox.setPrefColumnCount(70);
        textBox.setPrefRowCount(36);

        Pane thePane = new Pane();
        thePane.getChildren().add(topBar);
        thePane.getChildren().add(textBox);

        saveError.setContentText("Error: File could not be saved.");

        openError.setContentText("Error: File could not be opened.");

        Scene scene = new Scene(thePane, 800, 600);

        primaryStage.setTitle("Jordan Clay Text Editor");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * This inner class is the handler for the event of selecting New,
     * which is to start a new file.
     */
    class NewHandler implements EventHandler<ActionEvent> {

        public void handle(ActionEvent e) {
            newFile();
        }
    }

    /**
     * This inner class is the handler for the event of selecting Open,
     * which is to open a file.
     */
    class OpenHandler implements EventHandler<ActionEvent> {

        public void handle(ActionEvent e) {
            openFile();
        }
    }

    /**
     * This inner class is the handler for the event of selecting Save,
     * which is to save the current file.
     */
    class SaveHandler implements EventHandler<ActionEvent> {

        public void handle(ActionEvent e) {
            saveFile();
        }
    }

    /**
     * This inner class is the handler for the event of selecting Save As,
     * which is to save as another file.
     */
    class SaveAsHandler implements EventHandler<ActionEvent> {

        public void handle(ActionEvent e) {
            saveAsFile();
        }
    }
    
    /**
     * This inner class is the handler for the event of selecting Replace,
     * which is to replace all occurrences of a string with another string.
     */
    class ReplaceHandler implements EventHandler<ActionEvent> {
        
        public void handle(ActionEvent e) {
            replace();
        }
    }

    /**
     * This method will call another method to ask if the user wants to save
     * a file and then start a new file.
     * 
     * PreCondition: None
     * PostCondition: A new file has been started.
     * 
     */
    public void newFile() {
        promptForSave();
        if (canceled) {
            canceled = false;
        } else {
            textBox.clear();
            filename = "";
            isFile = false;
        }
    }

    /**
     * This method will call another method to ask if the user wants to save
     * a file and then open a file.
     * 
     * PreCondition: None
     * PostCondition: A file has been opened.
     * 
     */
    public void openFile() {
        promptForSave();
        if (canceled) {
            canceled = false;
        } else {
            TextInputDialog openDialog = new TextInputDialog();
            openDialog.setHeaderText("Enter the file name: ");
            Optional<String> name = openDialog.showAndWait();
            filename = name.get();
            File file = new File(filename);
            textBox.clear();
            int lineCounter = 0; // used to check if the line being loaded is the first line
            try {
                Scanner open = new Scanner(file);
                while (open.hasNext()) {
                    if (lineCounter == 0) { // first line
                        textBox.setText(textBox.getText() + open.nextLine());
                    } else {
                        textBox.setText(textBox.getText() + "\n" + open.nextLine());
                    }
                    lineCounter++;
                }
            } catch (IOException ex) {
                openError.showAndWait();
            }
        }
        openError.setContentText("Error: File could not be opened.");
    }

    /**
     * This method will save the current file.
     * 
     * PreCondition: None
     * PostCondition: The current file has been saved.
     * 
     */
    public void saveFile() {
        if (!isFile) {
            saveAsFile();
        } else {
            saveOutput();
        }
    }

    /**
     * This method will ask for a file name as which to save the document and
     * then save the file.
     * 
     * PreCondition: None
     * PostCondition: The file with the chosen name has been saved.
     * 
     */
    public void saveAsFile() {
        TextInputDialog saveAsDialog = new TextInputDialog();
        saveAsDialog.setHeaderText("Enter the file name: ");
        Optional<String> name = saveAsDialog.showAndWait();
        filename = name.get();
        saveOutput();
        isFile = true;
    }

    /**
     * This method will ask if the user wants to save a file and depending on
     * the decision save the file.
     * 
     * PreCondition: None
     * PostCondition: The file has been saved or the program has finished this
     * method.
     * 
     */
    public void promptForSave() {
        Alert promptForSaveDialog = new Alert(AlertType.CONFIRMATION);
        promptForSaveDialog.setHeaderText("Do you want to save this document first?");
        ButtonType saveType = new ButtonType("Save");
        ButtonType saveAsType = new ButtonType("Save As");
        ButtonType noType = new ButtonType("No");
        ButtonType cancelType = new ButtonType("Cancel", ButtonData.CANCEL_CLOSE);
        promptForSaveDialog.getButtonTypes().setAll(saveType, saveAsType, noType, cancelType);
        Optional<ButtonType> chosen = promptForSaveDialog.showAndWait();
        if (chosen.get() == saveType) {
            saveFile();
        } else if (chosen.get() == saveAsType) {
            saveAsFile();
        } else if (chosen.get() == cancelType) {
            canceled = true;
        }
    }

    /**
     * This method will write the document to a file.
     * 
     * PreCondition: None
     * PostCondition: The document has been written to the file.
     * 
     */
    public void saveOutput() {
        try {
            File file = new File(filename);
            PrintWriter fileWriter = new PrintWriter(file);
            ObservableList<CharSequence> docList = textBox.getParagraphs();
            Iterator<CharSequence> docIterator = docList.iterator();
            while (docIterator.hasNext()) {
                fileWriter.println(docIterator.next());
            }
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException ex) {
            saveError.showAndWait();
        }
    }

    /**
     * This method will ask for a string to replace and a string with which to
     * replace it, and replace all occurrences of it.
     * 
     * PreCondition: None
     * PostCondition: All occurrences of the string have been replaced with
     * another string.
     * 
     */
    public void replace() {
        TextInputDialog originalDialog = new TextInputDialog();
        TextInputDialog replacementDialog = new TextInputDialog();
        originalDialog.setHeaderText("Enter the case sensitive string to be replaced: ");
        replacementDialog.setHeaderText("Enter the string with which to replace the original string: ");
        Optional<String> original = originalDialog.showAndWait();
        String substring = original.get();
        Optional<String> replacement = replacementDialog.showAndWait();
        String newSubstring = replacement.get();
        ObservableList<CharSequence> docList = textBox.getParagraphs();
        Iterator<CharSequence> findIterator = docList.iterator();
        String line = "";
        boolean substringStarted = false;
        int replacedStrings = 0; // number of strings on a line that are replaced
        int startingIndex = 0; // index where substring starts on the line
        int previousLineSum = 0;
        int lineNumber = 0; // for the iterator used in multiple replacements per line
        while (findIterator.hasNext()) {
            line = findIterator.next().toString();
            for (int i = 0; i < line.length(); i++) { // for loop for iterating within the line
                //line = debugIterator.next();
                Iterator<CharSequence> multiIterator = docList.iterator();
                for (int j = 0; j <= lineNumber; j++) {
                    line = multiIterator.next().toString();
                }
                if (substringStarted && ((i - startingIndex) >= (substring.length()))) { // finished checking substring
                    textBox.replaceText(previousLineSum + startingIndex, previousLineSum + startingIndex + substring.length(), newSubstring);
                    replacedStrings++;
                    substringStarted = false;
                    i = 0; // resetting the index after a replacement so no characters will be skipped after making a line shorter
                }
                else if (!substringStarted) { // substring not already started
                    if (line.charAt(i) == substring.charAt(0)) { // character matches first character of substring
                        substringStarted = true;
                        startingIndex = i;
                    } else {
                        substringStarted = false;
                    }
                } else { // during substring
                    if (line.charAt(i) != substring.charAt(i - startingIndex)) {
                        substringStarted = false;
                        if (line.charAt(i) == substring.charAt(0)) { // if the character that does not match is the first character of substring
                            substringStarted = true;
                            startingIndex = i;
                        }
                    }
                }
                if ((i == line.length() - 1) && substringStarted) { // for when the string to replace is at the end of a line
                    textBox.replaceText(previousLineSum + startingIndex, previousLineSum + startingIndex + substring.length(), newSubstring);
                    replacedStrings++;
                    substringStarted = false;
                    i = 0;
                }
            }
            substringStarted = false;
            startingIndex = 0;
            previousLineSum += line.length() + 1; // + 1 because of line breaks
            replacedStrings = 0;
            lineNumber++;
        }
    }
}
